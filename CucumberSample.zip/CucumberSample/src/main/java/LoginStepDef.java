import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginStepDef {

    WebDriver driver;

    @Given("the user visits the chrome webpage")
    public void the_user_visits_the_chrome_webpage()
    {
        driver=new ChromeDriver();
    }

    @When("the user redirects to the url")
    public void the_user_redirects_to_the_url()
    {
        driver.get("https://www.google.com/");
    }

    @Then("the user should be redirected to homepage and title should be Google")
    public void the_user_should_be_redirected_to_homepage_and_title_should_be_Google()
    {
        String title=driver.getTitle();
        System.out.println("title is :" + title);
    }


}
